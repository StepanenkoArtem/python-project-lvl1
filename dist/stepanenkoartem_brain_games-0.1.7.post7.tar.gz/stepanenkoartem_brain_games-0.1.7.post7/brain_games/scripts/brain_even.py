import brain_games.bg_even


def main():
    brain_games.bg_even.start()


if __name__ == '__main__':
    main()
