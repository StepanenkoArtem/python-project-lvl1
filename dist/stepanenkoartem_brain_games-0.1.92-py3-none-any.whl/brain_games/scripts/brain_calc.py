import brain_games.calc


def main():
    brain_games.calc.run()


if __name__ == '__main__':
    main()
