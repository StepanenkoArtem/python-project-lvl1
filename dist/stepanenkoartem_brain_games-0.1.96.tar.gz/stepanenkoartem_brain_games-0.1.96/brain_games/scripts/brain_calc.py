import brain_games.games.calc as calc


def main():
    calc.run()


if __name__ == '__main__':
    main()
