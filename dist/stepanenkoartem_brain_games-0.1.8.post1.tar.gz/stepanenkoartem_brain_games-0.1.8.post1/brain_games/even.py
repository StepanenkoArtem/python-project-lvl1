import cli


cli.greeting()


def run():
    print("Test run of game")
