import brain_games.cli


def main():
    print('Welcome to the Brain Games! (v.0.1.7-7)')
    brain_games.cli.run()


if __name__ == '__main__':
    main()
