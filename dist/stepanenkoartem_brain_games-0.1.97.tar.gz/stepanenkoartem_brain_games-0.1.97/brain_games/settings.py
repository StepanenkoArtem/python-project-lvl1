INCORRECT = "{} is wrong answer ;(.Correct answer was '{}'" \
            ".\n Let's try again, {}!'"
CORRECT = "Correct!"
CONGRATS = "Congratulations,{}"

GREETINGS = "Welcome to the Brain Games!"

# Correct answers minimum
MIN_CORRECT_ANSWERS = 3

# Minimum and maximum of range for random integer
RANGE = [10, 100]
