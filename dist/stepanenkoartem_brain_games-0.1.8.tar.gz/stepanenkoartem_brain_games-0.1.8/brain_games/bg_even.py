def start():
    print("Test run of game")
