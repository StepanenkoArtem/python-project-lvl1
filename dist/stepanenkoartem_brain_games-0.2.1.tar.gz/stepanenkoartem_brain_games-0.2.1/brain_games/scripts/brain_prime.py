import brain_games.games.prime as prime


def main():
    prime.run()


if __name__ == "__main__":
    main()
