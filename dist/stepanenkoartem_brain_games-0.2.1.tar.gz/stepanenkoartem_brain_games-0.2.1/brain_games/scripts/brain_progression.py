import brain_games.games.progression as progression


def main():
    progression.run()


if __name__ == '__main__':
    main()
