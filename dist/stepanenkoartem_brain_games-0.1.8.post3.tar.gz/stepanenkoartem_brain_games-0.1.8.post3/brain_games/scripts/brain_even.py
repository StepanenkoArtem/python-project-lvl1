import brain_games.even


def main():
    brain_games.even.run()


if __name__ == '__main__':
    main()
