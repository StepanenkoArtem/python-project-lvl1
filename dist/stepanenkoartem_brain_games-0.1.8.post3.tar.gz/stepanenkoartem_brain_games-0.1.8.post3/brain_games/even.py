import brain_games.cli
import prompt


GAME_TASK = 'Answer "yes" if number even otherwise answer "no"'


brain_games.cli.greeting()
print(GAME_TASK)
brain_games.cli.ask_name()


def run():
    print("Test run of game!!1")
