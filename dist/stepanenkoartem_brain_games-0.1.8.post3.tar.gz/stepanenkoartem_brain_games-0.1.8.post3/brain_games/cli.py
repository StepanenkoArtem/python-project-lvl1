import prompt


def greeting():
    print('Welcome to Brain Games!!')


def ask_name():
    name = prompt.string("May I have your name?: ")
    print("Hello, {}".format(name))
