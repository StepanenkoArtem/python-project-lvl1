import brain_games.cli


brain_games.cli.greeting()


def run():
    print("Test run of game")
