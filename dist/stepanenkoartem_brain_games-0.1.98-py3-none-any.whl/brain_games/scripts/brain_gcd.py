import brain_games.games.gcd as gcd


def main():
    gcd.run()


if __name__ == '__main__':
    main()
