import prompt


def run():
    print("Test string")
    name = prompt.string("Privet")
    print(name)
