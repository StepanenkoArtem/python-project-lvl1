# Subtitle
GAME_TASK = 'Answer "yes" if number even otherwise answer "no"'

# Correct answers minimum
MIN_CORRECT_ANSWERS = 3

# Minimum and maximum of range for random integer
RANGE = [3, 100]
