import brain_games.games.even as even


def main():
    even.run()


if __name__ == '__main__':
    main()
